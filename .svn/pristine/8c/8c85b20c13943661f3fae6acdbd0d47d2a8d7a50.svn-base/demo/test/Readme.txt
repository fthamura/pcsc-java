Modify the setEnvironment.bat (Windows) or setEnvironment.sh (Linux) to point to
the correct directories. Some of the test programs need the IAIK JCE library to
run. This library can be downloaded from http://jcewww.iaik.at for evaluation.
GetInfo is a simple test to start with. It prints information about a PKCS#11
driver, its slots, its tokens and the objects on the tokens.
